"""Laudos Técnicos com IA. Rode com: streamlit run app.py"""
import time
import uuid
import streamlit as st
import auth, checklists as C, db, ia, pdf, validacao as V

st.set_page_config(page_title="Laudos Técnicos", page_icon="⚡", layout="centered")
db.init()
auth.garantir_admin()
AVISO = "O texto gerado por IA é um rascunho. A revisão e a assinatura do engenheiro responsável são obrigatórias."
S = st.session_state


def tela_login():
    st.title("⚡ Laudos Técnicos")
    t1, t2 = st.tabs(["Entrar", "Criar conta"])
    with t1, st.form("login"):
        e, s = st.text_input("E-mail"), st.text_input("Senha", type="password")
        if st.form_submit_button("Entrar"):
            try:
                uid = auth.entrar(e, s)
                S.uid, S.perfil = uid, auth.perfil(uid)
                st.rerun()
            except (ValueError, PermissionError) as ex:
                st.error(str(ex))
    with t2, st.form("cadastro"):
        e, s = st.text_input("E-mail", key="ce"), st.text_input("Senha (mínimo 8 caracteres)", type="password", key="cs")
        if st.form_submit_button("Criar conta"):
            try:
                auth.cadastrar(e, s)
                st.success("Conta criada. Você poderá entrar assim que o administrador autorizar o acesso.")
            except (ValueError, PermissionError) as ex:
                st.error(str(ex))


def abrir(lid, dados):
    S.lid, S.d, S.pdf = lid, dados, None
    st.rerun()


def tela_lista():
    st.subheader("Meus laudos")
    if st.button("Novo laudo", type="primary"):
        abrir(uuid.uuid4().hex, C.novo())
    busca = st.text_input("Buscar por cliente ou local").lower()
    itens = [l for l in db.listar(S.uid) if busca in (l["cliente"] + " " + l["local"]).lower()]
    if not itens:
        st.info("Nenhum laudo encontrado. Crie o primeiro para começar.")
    for l in itens:
        with st.container(border=True):
            st.markdown(f"**{l['cliente'] or 'Sem cliente'}**  \n{l['local']} · {l['data']} · {C.TIPOS[l['tipo']]}")
            a, b, c = st.columns(3)
            if a.button("Abrir", key="o" + l["id"]):
                abrir(l["id"], db.obter(S.uid, l["id"]))
            if b.button("Duplicar", key="d" + l["id"]):
                cp = db.obter(S.uid, l["id"])
                cp.update(laudo=None, ck={}, art="")
                abrir(uuid.uuid4().hex, cp)
            if c.button("Excluir", key="x" + l["id"]):
                db.excluir(S.uid, l["id"])
                st.rerun()


def txt(d, k, rotulo, area=False, **kw):
    f = st.text_area if area else st.text_input
    d[k] = f(rotulo, d.get(k, ""), key=f"{S.lid}_{k}", **kw)


def sel(d, k, rotulo, opcoes, fmt=str):
    i = opcoes.index(d[k]) if d[k] in opcoes else 0
    d[k] = st.selectbox(rotulo, opcoes, index=i, key=f"{S.lid}_{k}", format_func=fmt)


def salvar():
    db.salvar_laudo(S.uid, S.lid, S.d)
    st.toast("Laudo salvo.")


def tela_editor():
    d, lid = S.d, S.lid
    t = st.tabs(["Identificação", "Instalação", "Checklist", "Medições", "Fotos", "Laudo"])
    with t[0]:
        sel(d, "tipo", "Tipo de laudo", list(C.TIPOS), C.TIPOS.get)
        txt(d, "cliente", "Cliente"); txt(d, "doc", "CPF/CNPJ"); txt(d, "local", "Endereço da instalação")
        d["data"] = st.date_input("Data da inspeção", value=__import__("datetime").date.fromisoformat(d["data"]),
                                  key=f"{lid}_data").isoformat()
        sel(d, "finalidade", "Finalidade", C.FINALIDADES)
        txt(d, "resp", "Engenheiro responsável"); txt(d, "crea", "CREA"); txt(d, "art", "Nº da ART")
        d["spda"] = st.checkbox("Incluir SPDA (NBR 5419)", d["spda"], key=f"{lid}_spda")
        ant = db.historico(S.uid, d["cliente"], lid)
        if ant:
            st.caption("Laudos anteriores deste cliente: " + "; ".join(f"{a['data']} ({C.TIPOS[a['tipo']]})" for a in ant))
    with t[1]:
        txt(d, "tensao", "Tensão nominal (V ou kV)"); txt(d, "potencia", "Potência instalada / demanda (kW)")
        sel(d, "esquema", "Esquema de aterramento", C.ESQUEMAS)
        txt(d, "quadros", C.LB[d["tipo"]][0], area=True); txt(d, "desc", "Descrição geral da instalação", area=True)
    with t[2]:
        for g in C.grupos(d):
            st.markdown(f"**{C.CK[g]['t']}**")
            for k, texto in C.CK[g]["l"]:
                v = d["ck"].setdefault(k, {})
                op = ["C", "NC", "NA"]
                nomes = {"C": "Conforme", "NC": "Não conforme", "NA": "Não se aplica"}
                v["s"] = st.radio(texto, op, index=op.index(v["s"]) if v.get("s") in op else None,
                                  format_func=nomes.get, horizontal=True, key=f"{lid}_{k}_s")
                v["o"] = st.text_input("Observação", v.get("o", ""), key=f"{lid}_{k}_o", label_visibility="collapsed",
                                       placeholder="Observação (opcional)")
    with t[3]:
        c1, c2 = st.columns(2)
        with c1: txt(d, "res", "Resistência de aterramento (Ω)")
        with c2: txt(d, "iso", "Isolação mínima (MΩ)")
        txt(d, "cont", C.LB[d["tipo"]][1]); txt(d, "obs", "Outras medições e observações", area=True)
        for _, ok, msg in V.med_flags(d):
            (st.success if ok else st.error)(msg)
        st.caption("As referências de 10 Ω e 0,5 MΩ são sinalizações de apoio. A avaliação final é do engenheiro.")
    with t[4]:
        itens = [""] + [k for g in C.grupos(d) for k, _ in C.CK[g]["l"]]
        arqs = st.file_uploader("Fotos (JPG ou PNG, até 5 MB cada)", type=["jpg", "jpeg", "png"], accept_multiple_files=True,
                                key=f"{lid}_up")
        item = st.selectbox("Vincular ao item", itens, key=f"{lid}_fi")
        leg = st.text_input("Legenda", key=f"{lid}_fl")
        if st.button("Adicionar fotos") and arqs:
            salvar()
            for a in arqs:
                try:
                    db.add_foto(S.uid, lid, item, leg, a.getvalue())
                except ValueError as ex:
                    st.error(f"{a.name}: {ex}")
            st.rerun()
        for f in db.listar_fotos(S.uid, lid):
            st.image(f["imagem"], caption=f"{f['item']} {f['legenda']}", width=260)
            if st.button("Remover", key="rf" + f["id"]):
                db.excluir_foto(S.uid, f["id"]); st.rerun()
    with t[5]:
        st.warning(AVISO)
        nc = V.nao_conformidades(d)
        st.write(f"{len(nc)} não conformidade(s) identificada(s).")
        if st.button("Gerar texto com IA"):
            pend = V.pendencias(d)
            if pend:
                st.warning("Preencha as pendências antes de gerar o laudo: " + "; ".join(pend))
                st.stop()
            with st.spinner("Redigindo o laudo…"):
                try:
                    d["laudo"] = ia.gerar_texto(d)
                    for k in ("analise", "recs", "conclusao"):
                        S.pop(f"{lid}_L{k}", None)
                    salvar()
                except RuntimeError as e:
                    st.error(str(e))
        if d.get("laudo"):
            for k, n in [("analise", "Análise técnica"), ("recs", "Recomendações"), ("conclusao", "Conclusão")]:
                d["laudo"][k] = st.text_area(n, d["laudo"].get(k, ""), height=180, key=f"{lid}_L{k}")
            if st.button("Preparar PDF"):
                p = V.pendencias(d)
                if p:
                    st.warning("Pendências: " + "; ".join(p))
                S.pdf = pdf.gerar_pdf(d, db.listar_fotos(S.uid, lid), lid)
            if S.get("pdf"):
                st.download_button("Baixar PDF", S.pdf, file_name=f"laudo-{(d['cliente'] or 'instalacao').replace(' ', '_')}.pdf",
                                   mime="application/pdf")
    st.divider()
    a, b = st.columns(2)
    if a.button("Salvar", type="primary"):
        salvar()
    if b.button("Voltar à lista"):
        salvar(); S.lid = None; st.rerun()


def tela_trocar(obrigatoria):
    st.subheader("Alterar senha")
    if obrigatoria:
        st.info("Sua senha foi redefinida pelo administrador. Escolha uma senha nova para continuar.")
    with st.form("troca"):
        a, n, n2 = (st.text_input("Senha atual", type="password"), st.text_input("Nova senha", type="password"),
                    st.text_input("Repita a nova senha", type="password"))
        ok = st.form_submit_button("Salvar nova senha")
    if ok:
        try:
            if n != n2:
                raise ValueError("As senhas novas não conferem.")
            auth.trocar_senha(S.uid, a, n)
            S.pop("trocar", None)
            st.rerun()
        except ValueError as ex:
            st.error(str(ex))
    if not obrigatoria and st.button("Cancelar"):
        S.pop("trocar", None)
        st.rerun()


def tela_admin():
    st.subheader("Administração de acessos")
    st.caption("O administrador gerencia contas e senhas, mas não tem acesso aos laudos dos usuários.")
    if S.get("temp"):
        email, senha = S.pop("temp")
        st.success(f"Senha temporária de {email}: `{senha}`. Ela aparece só agora; envie ao usuário, que terá de trocá-la no primeiro acesso.")
    try:
        us = auth.listar_usuarios(S.uid)
        pend = [u for u in us if not u["aprovado"]]
        st.markdown(f"**Aguardando autorização ({len(pend)})**")
        if not pend:
            st.write("Nenhum cadastro pendente.")
        for u in pend:
            with st.container(border=True):
                st.write(u["email"])
                a, b = st.columns(2)
                if a.button("Autorizar", key=f"ap{u['id']}", type="primary"):
                    auth.aprovar(S.uid, u["id"]); st.rerun()
                if b.button("Recusar", key=f"rc{u['id']}"):
                    auth.recusar(S.uid, u["id"]); st.rerun()
        st.markdown("**Usuários**")
        for u in [x for x in us if x["aprovado"]]:
            with st.container(border=True):
                marcas = [("Administrador" if u["papel"] == "admin" else "Usuário"), ("Ativo" if u["ativo"] else "Desativado")]
                if u["bloqueado"]:
                    marcas.append("Bloqueado")
                st.markdown(f"**{u['email']}**  \n{' · '.join(marcas)}")
                if u["id"] != S.uid:
                    a, b, c = st.columns(3)
                    if u["bloqueado"] and a.button("Desbloquear", key=f"db{u['id']}"):
                        auth.desbloquear(S.uid, u["id"]); st.rerun()
                    if b.button("Redefinir senha", key=f"rs{u['id']}"):
                        S.temp = (u["email"], auth.redefinir_senha(S.uid, u["id"])); st.rerun()
                    if c.button("Reativar" if not u["ativo"] else "Desativar", key=f"at{u['id']}"):
                        auth.definir_ativo(S.uid, u["id"], not u["ativo"]); st.rerun()
        with st.expander("Registro de ações"):
            for r in auth.auditoria_recente(S.uid):
                st.write(f"{time.strftime('%d/%m/%Y %H:%M', time.localtime(r['em']))} · {r['admin']} · {r['acao']} · {r['alvo']}")
    except (ValueError, PermissionError) as ex:
        st.error(str(ex))


if "uid" not in S:
    tela_login()
else:
    p = auth.perfil(S.uid)  # confere a cada ação: conta desativada perde a sessão
    if p is None:
        S.clear(); st.rerun()
    S.perfil = p
    with st.sidebar:
        st.write(p["email"])
        area = st.radio("Área", ["Laudos", "Administração"], key="area") if p["papel"] == "admin" else "Laudos"
        if st.button("Alterar senha"):
            S.trocar = True; st.rerun()
        if st.button("Sair"):
            S.clear(); st.rerun()
    if p["deve_trocar"] or S.get("trocar"):
        tela_trocar(p["deve_trocar"])
    elif area == "Administração":
        tela_admin()
    elif S.get("lid"):
        tela_editor()
    else:
        tela_lista()
